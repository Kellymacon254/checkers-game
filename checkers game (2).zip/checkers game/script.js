const board = document.getElementById("board");
const cells = [];
let selectedPiece = null;

// Initialize the board
function createBoard() {
  for (let row = 0; row < 8; row++) {
    cells[row] = [];
    for (let col = 0; col < 8; col++) {
      const cell = document.createElement("div");
      cell.classList.add("cell");
      if ((row + col) % 2 === 0) {
        cell.classList.add("dark");
      }
      cell.dataset.row = row;
      cell.dataset.col = col;
      cell.addEventListener("click", () => handleCellClick(row, col));
      board.appendChild(cell);
      cells[row][col] = cell;
    }
  }
}

// Place initial pieces
function placePieces() {
  for (let row = 0; row < 3; row++) {
    for (let col = 0; col < 8; col++) {
      if ((row + col) % 2 !== 0) {
        const piece = document.createElement("div");
        piece.classList.add("piece", "player2");
        cells[row][col].appendChild(piece);
      }
    }
  }
  for (let row = 5; row < 8; row++) {
    for (let col = 0; col < 8; col++) {
      if ((row + col) % 2 !== 0) {
        const piece = document.createElement("div");
        piece.classList.add("piece", "player1");
        cells[row][col].appendChild(piece);
      }
    }
  }
}

// Handle cell clicks
function handleCellClick(row, col) {
  const cell = cells[row][col];
  const piece = cell.querySelector(".piece");

  if (selectedPiece) {
    movePiece(selectedPiece, row, col);
    selectedPiece = null;
  } else if (piece) {
    selectedPiece = { row, col, element: piece };
  }
}

// Move a piece
function movePiece(from, toRow, toCol) {
  const toCell = cells[toRow][toCol];
  const fromCell = cells[from.row][from.col];

  if (!toCell.querySelector(".piece")) {
    toCell.appendChild(from.element);
    fromCell.removeChild(from.element);
  }
}

// Start the game
createBoard();
placePieces();